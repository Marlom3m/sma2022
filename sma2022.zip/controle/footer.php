<hr>
<footer class="container ">
  <img src="<?php echo BASEURL; ?>imagens/logoifmspp.png" width="30%" class="mx-auto d-block">
  <p class=" text-center" style="font-size: 11px"> Desenvolvido por: <br>Prof. Marlom Marsal Marques - IFMS Campus Ponta Porã <br>email: marlom.marques@ifms.edu.br</p>
</footer>
<script src="<?php echo BASEURL; ?>cdn/jquery/dist/jquery.slim.js"></script>
<script src="../cdn/js/jquery-ui.js" type="text/javascript"></script>
<script src="<?php echo BASEURL; ?>cdn/popper.js/dist/popper.js"></script>
<script src="<?php echo BASEURL; ?>cdn/js/bootstrap.js"></script>
</main> <!-- /container -->
</div>
</div>
</body>
</html>
