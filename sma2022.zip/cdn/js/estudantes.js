function deletar(id){
	console.log(5 + 6);
	$("#confirm").attr("href","delete.php?id="+id);
}

	
