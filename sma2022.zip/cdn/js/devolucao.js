function devolver(id){
	$("#confirm").attr("href","alterar.php?id="+id);
}

