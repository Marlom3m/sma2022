function mStatus(id,status){
	$("#confirm").attr("href","delete.php?id="+id+"&status="+status);
}



	
