
<div class="modal fade" id="delete-modal">	  
	<div class="modal-dialog">	    
		<div class="modal-content">	      
			<div class="modal-header">	        
				<h4 class="modal-title">Excluir Participante</h4> 
				<button type="button" class="close" data-dismiss="modal">&times;</button>	           
			</div>	      
			<div class="modal-body">	        
				Deseja realmente excluir o participante dessa atividade?	      
			</div>	      
			<div class="modal-footer">	        
				<a id="confirm" class="btn btn-primary" href="">Sim</a>	        
				<a id="cancel" class="btn btn-default" data-dismiss="modal">Não</a>	      
			</div>	    
		</div>	  
	</div>	
</div> 
